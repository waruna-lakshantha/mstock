<div id="msgReg" class="w3-modal">
<div class="w3-modal-content w3-animate-top w3-card-8">
    <header id="msgRegHed" class="w3-container">
    <span onclick="document.getElementById('msgReg').style.display='none'"
    class="w3-closebtn">&times;</span>
    <h2 id="msgRegTitle">Modal Header</h2>
    </header>
    <div class="w3-container">
    <p id="msgRegDes">Some text..</p>
    </div>
</div>
</div>